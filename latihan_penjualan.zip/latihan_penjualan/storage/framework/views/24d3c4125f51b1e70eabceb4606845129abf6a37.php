<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="com-md-12">
			<div class="panel panel-default">
				<div class="panel-head container-fluid" style="margin-top: 10px;">
					<p>Tambah Data Produk</p>
				</div>
				<div class="panel-body">
					<form class="form-horizontal" action="<?php echo e(route('produk.store')); ?>" method="post"> <?php echo e(csrf_field()); ?>

						<div class="form-group">
							<label class="control-label" col-sm-2>Nama Produk</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="nama">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label" col-sm-2>Kategori Produk</label>
							<div class="col-sm-10">
								<select class="form-control" name="kategori">
									<option value="">Pilih Kategori</option>
									<?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($k -> id); ?>"><?php echo e($k -> nama); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label" col-sm-2>Qty Awal</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="qty">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label" col-sm-2>Harga Jual</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="jual">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label" col-sm-2>Harga Beli</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="beli">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-2 col-sm-10">
								<button type="submit" class="btn btn-primary">Simpan</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\latihan_penjualan\resources\views/produk/create.blade.php ENDPATH**/ ?>